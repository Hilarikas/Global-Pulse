package com.globalpulse.pulse.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * Loads live headlines through the rss2json relay (CORS-free from a native app,
 * clean JSON). Falls back to bundled sample data when nothing loads.
 */
class RssRepository {

    /** Loads all feeds; falls back to sample data if nothing loads. */
    suspend fun load(): NewsLoad = coroutineScope {
        val perFeed = FEEDS.map { feed ->
            async(Dispatchers.IO) {
                feed to runCatching { fetchFeed(feed) }.getOrDefault(emptyList())
            }
        }.awaitAll()
        val statuses = perFeed.map { (f, arts) -> FeedStatus(f.name, arts.isNotEmpty(), arts.size) }
        val seen = HashSet<String>()
        val live = perFeed.flatMap { it.second }.filter { seen.add(it.title.lowercase().take(60)) }
        if (live.isNotEmpty()) NewsLoad(live, false, statuses)
        else NewsLoad(SampleData.articles(), true, statuses)
    }

    private fun fetchFeed(feed: Feed): List<Article> {
        val api = "https://api.rss2json.com/v1/api.json?rss_url=" +
                URLEncoder.encode(feed.url, "UTF-8") + "&count=25"
        val conn = (URL(api).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12_000
            readTimeout = 12_000
        }
        try {
            if (conn.responseCode !in 200..299) return emptyList()
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(body)
            if (json.optString("status") != "ok") return emptyList()
            val items = json.optJSONArray("items") ?: return emptyList()
            val out = ArrayList<Article>(items.length())
            for (i in 0 until items.length()) {
                val it = items.getJSONObject(i)
                val title = stripHtml(it.optString("title"))
                if (title.isBlank()) continue
                val img = it.optString("thumbnail").ifBlank {
                    it.optJSONObject("enclosure")?.optString("link").orEmpty()
                }.ifBlank { imgFromHtml(it.optString("content").ifBlank { it.optString("description") }) }
                out.add(
                    Article(
                        title = title,
                        desc = stripHtml(it.optString("description").ifBlank { it.optString("content") }).take(320),
                        link = it.optString("link"),
                        image = img.ifBlank { null },
                        source = feed.name,
                        category = feed.category,
                        publishedAt = parseDate(it.optString("pubDate"))
                    )
                )
            }
            return out
        } finally {
            conn.disconnect()
        }
    }

    companion object {
        private val TAG_RE = Regex("<[^>]+>")
        private val WS_RE = Regex("\\s+")
        private val IMG_RE = Regex("<img[^>]+src=\"([^\">]+)\"")

        fun stripHtml(s: String?): String =
            s?.replace(TAG_RE, " ")?.replace(WS_RE, " ")?.trim().orEmpty()

        private fun imgFromHtml(s: String?): String =
            s?.let { IMG_RE.find(it)?.groupValues?.get(1) }.orEmpty()

        private fun parseDate(s: String?): Long {
            if (s.isNullOrBlank()) return System.currentTimeMillis()
            val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            fmt.timeZone = TimeZone.getTimeZone("UTC")
            return runCatching { fmt.parse(s)?.time }.getOrNull() ?: System.currentTimeMillis()
        }
    }
}
