/* ============================================================
   GLOBAL PULSE — Extraction & Feed Service (Cloudflare Worker)
   Single file, no build step. Paste into a Cloudflare Worker.

   Routes (all send CORS: * so the app can call from file:// / WebView / web):
     GET /                      → health/help
     GET /feed?url=<rss>        → SSRF-safe RSS/Atom proxy (raw XML)
     GET /extract?url=<article> → server-side full-article extraction (JSON)
     GET /health                → source success-rates & extraction stats (§13.1)

   Observability: per-source extraction stats are aggregated. If a KV namespace
   named STATS is bound, stats persist across requests; otherwise they fall back
   to ephemeral in-memory counters (labeled as such in /health).

   Safety: blocks private/loopback/link-local hosts and non-http(s) schemes;
   enforces timeout, redirect-follow with size cap, and content-type checks.
   Does NOT bypass paywalls/anti-bot — blocked stays BLOCKED.
   ============================================================ */

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};
const MAX_BYTES = 2_500_000;      // 2.5 MB response cap
const FETCH_TIMEOUT_MS = 12_000;
const FULL_THRESHOLD_WORDS = 250;
const BLOCK_RE = /(subscribe to (continue|read)|sign ?in to (read|continue)|create a (free )?account|for subscribers|this (article|content) is for|log ?in to continue|register to continue|become a (member|subscriber)|please enable javascript|are you a robot|access denied|verify you are human)/i;
const STATUSES = ["FULL", "SUMMARY", "BLOCKED", "TOO_SHORT", "MALFORMED", "EXTERNAL_ONLY"];

/* Ephemeral in-isolate stats (used when no KV binding is present). */
const MEM = { hosts: {}, totals: { requests: 0 }, since: Date.now() };

export default {
  async fetch(request, env, ctx) {
    if (request.method === "OPTIONS") return new Response(null, { headers: CORS });
    const url = new URL(request.url);
    try {
      if (url.pathname === "/feed") return await handleFeed(url.searchParams.get("url"));
      if (url.pathname === "/extract") return await handleExtract(url.searchParams.get("url"), env, ctx);
      if (url.pathname === "/health") return await handleHealth(env);
      return json({ service: "global-pulse-extractor", version: "worker-2", routes: ["/feed?url=", "/extract?url=", "/health"] });
    } catch (e) {
      return json({ error: String((e && e.message) || e) }, 500);
    }
  },
};

/* ---------- Helpers ---------- */
function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { ...CORS, "Content-Type": "application/json; charset=utf-8", "Cache-Control": "public, max-age=300" },
  });
}
function bad(msg, status = 400) { return json({ error: msg }, status); }

/** SSRF guard: only public http(s) hosts. */
function validateTarget(raw) {
  if (!raw) return "missing url";
  let u;
  try { u = new URL(raw); } catch { return "invalid url"; }
  if (u.protocol !== "http:" && u.protocol !== "https:") return "unsupported scheme";
  const h = u.hostname.toLowerCase();
  if (h === "localhost" || h.endsWith(".localhost") || h.endsWith(".internal") || h.endsWith(".local")) return "blocked host";
  if (/^(127\.|10\.|192\.168\.|169\.254\.|0\.)/.test(h)) return "blocked host";
  if (/^172\.(1[6-9]|2\d|3[0-1])\./.test(h)) return "blocked host";
  if (h === "::1" || h === "[::1]" || h.startsWith("fc") || h.startsWith("fd")) return "blocked host";
  if (h === "169.254.169.254") return "blocked host"; // cloud metadata
  return null;
}
function hostOf(raw) { try { return new URL(raw).hostname.replace(/^www\./, ""); } catch { return "unknown"; } }

async function safeFetch(target, accept) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT_MS);
  try {
    return await fetch(target, {
      redirect: "follow",
      signal: ctrl.signal,
      cf: { cacheTtl: 300, cacheEverything: true },
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; GlobalPulseBot/1.0; +news-reader)",
        "Accept": accept,
      },
    });
  } finally { clearTimeout(t); }
}
async function readCapped(res) {
  const reader = res.body && res.body.getReader ? res.body.getReader() : null;
  if (!reader) return await res.text();
  const chunks = []; let total = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.length;
    if (total > MAX_BYTES) { reader.cancel(); break; }
    chunks.push(value);
  }
  return new TextDecoder("utf-8").decode(concat(chunks));
}
function concat(chunks) {
  let len = 0; chunks.forEach(c => len += c.length);
  const out = new Uint8Array(len); let o = 0;
  chunks.forEach(c => { out.set(c, o); o += c.length; });
  return out;
}

/* ---------- Observability (§13.1) ---------- */
function bump(store, host, status, ms) {
  const t = store.totals; t.requests = (t.requests || 0) + 1; t[status] = (t[status] || 0) + 1;
  t.msSum = (t.msSum || 0) + (ms || 0);
  const h = store.hosts[host] || (store.hosts[host] = { total: 0, msSum: 0 });
  h.total++; h[status] = (h[status] || 0) + 1; h.msSum += (ms || 0); h.lastMs = ms || 0; h.lastAt = Date.now();
}
function logExtract(env, ctx, host, status, ms) {
  bump(MEM, host, status, ms);
  if (env && env.STATS && ctx) {
    ctx.waitUntil((async () => {
      try {
        const cur = JSON.parse((await env.STATS.get("stats")) || '{"hosts":{},"totals":{"requests":0},"since":0}');
        if (!cur.since) cur.since = Date.now();
        bump(cur, host, status, ms);
        await env.STATS.put("stats", JSON.stringify(cur));
      } catch (e) { /* ignore logging failures */ }
    })());
  }
}
function pct(n, d) { return d ? Math.round((n / d) * 100) : 0; }
function summarize(store) {
  const breakdown = s => { const o = {}; STATUSES.forEach(k => o[k] = s[k] || 0); return o; };
  const hosts = Object.entries(store.hosts).map(([host, h]) => ({
    host, total: h.total,
    fullRatePct: pct(h.FULL || 0, h.total),
    avgMs: h.total ? Math.round(h.msSum / h.total) : 0,
    breakdown: breakdown(h),
    lastAt: h.lastAt || null,
  })).sort((a, b) => b.total - a.total);
  const t = store.totals;
  return {
    requests: t.requests || 0,
    fullRatePct: pct(t.FULL || 0, t.requests || 0),
    avgMs: t.requests ? Math.round((t.msSum || 0) / t.requests) : 0,
    statusTotals: breakdown(t),
    since: store.since || null,
    hosts,
  };
}
async function handleHealth(env) {
  if (env && env.STATS) {
    try {
      const cur = JSON.parse((await env.STATS.get("stats")) || '{"hosts":{},"totals":{"requests":0}}');
      return json({ ok: true, storage: "kv", ...summarize(cur) });
    } catch (e) { /* fall through to memory */ }
  }
  return json({ ok: true, storage: "memory (ephemeral — bind a KV namespace named STATS for persistent stats)", ...summarize(MEM) });
}

/* ---------- /feed ---------- */
async function handleFeed(raw) {
  const err = validateTarget(raw); if (err) return bad(err);
  const res = await safeFetch(raw, "application/rss+xml, application/atom+xml, application/xml, text/xml, */*");
  if (!res.ok) return bad("upstream " + res.status, 502);
  const body = await readCapped(res);
  return new Response(body, { headers: { ...CORS, "Content-Type": "application/xml; charset=utf-8", "Cache-Control": "public, max-age=180" } });
}

/* ---------- /extract ---------- */
async function handleExtract(raw, env, ctx) {
  const started = Date.now();
  const finish = (obj) => { logExtract(env, ctx, hostOf(raw || ""), obj.status || "MALFORMED", Date.now() - started); return json(obj); };
  const err = validateTarget(raw); if (err) return finish({ status: "EXTERNAL_ONLY", error: err });
  let res;
  try { res = await safeFetch(raw, "text/html,application/xhtml+xml,*/*"); }
  catch (e) { return finish({ status: "MALFORMED", error: "fetch failed" }); }
  if (!res.ok) return finish({ status: (res.status === 401 || res.status === 403) ? "BLOCKED" : "MALFORMED", httpStatus: res.status });
  const ct = (res.headers.get("content-type") || "").toLowerCase();
  if (!ct.includes("html")) return finish({ status: "EXTERNAL_ONLY", contentType: ct });
  const html = await readCapped(res);
  return finish(extract(html, res.url || raw));
}

/* ---------- Extraction (regex-based, dependency-free) ---------- */
function metaContent(head, name) {
  const re = new RegExp(`<meta[^>]+(?:property|name)=["']${name}["'][^>]*>`, "i");
  const m = head.match(re);
  if (!m) return "";
  const c = m[0].match(/content=["']([^"']*)["']/i);
  return c ? decodeEntities(c[1].trim()) : "";
}
function decodeEntities(s) {
  return (s || "")
    .replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, " ")
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(+n));
}
function stripTags(s) { return decodeEntities((s || "").replace(/<[^>]+>/g, "")).replace(/\s+/g, " ").trim(); }

function sanitizeInlineHtml(s) {
  let out = s.replace(/<\/?(?:span|font|small|sup|sub|mark|time|cite|abbr|q)[^>]*>/gi, "");
  out = out.replace(/<a\b[^>]*>/gi, (tag) => {
    const h = tag.match(/href=["']([^"']+)["']/i);
    return h && /^https?:\/\//i.test(h[1]) ? `<a href="${h[1]}" target="_blank" rel="noopener">` : "<a>";
  });
  out = out.replace(/<(\/?)([a-z0-9]+)([^>]*)>/gi, (full, close, tag) => {
    const t = tag.toLowerCase();
    if (["a", "strong", "em", "b", "i", "br"].includes(t)) return `<${close}${t}>`;
    return "";
  });
  return out.replace(/\s+/g, " ").trim();
}

function extract(html, canonicalUrl) {
  const headMatch = html.match(/<head[\s\S]*?<\/head>/i);
  const head = headMatch ? headMatch[0] : html.slice(0, 8000);

  const title = metaContent(head, "og:title") || stripTags((html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i) || [])[1] || "") || metaContent(head, "twitter:title");
  const image = metaContent(head, "og:image") || metaContent(head, "twitter:image");
  let author = metaContent(head, "author") || metaContent(head, "article:author");
  if (/^https?:\/\//i.test(author) || /facebook|twitter|\.com\//i.test(author) || author.length > 70) author = "";
  const date = metaContent(head, "article:published_time") || metaContent(head, "article:modified_time") || metaContent(head, "date");

  let body = html
    .replace(/<script[\s\S]*?<\/script>/gi, "")
    .replace(/<style[\s\S]*?<\/style>/gi, "")
    .replace(/<(nav|header|footer|aside|form|figure|figcaption|noscript)[\s\S]*?<\/\1>/gi, " ");
  const art = body.match(/<article[\s\S]*?<\/article>/i);
  const scope = art ? art[0] : (body.match(/<body[\s\S]*?<\/body>/i) || [body])[0];

  const parts = [];
  const blockRe = /<(p|h2|h3|h4|blockquote|li)\b[^>]*>([\s\S]*?)<\/\1>/gi;
  let m;
  while ((m = blockRe.exec(scope)) !== null) {
    const tag = m[1].toLowerCase();
    const inner = m[2];
    const text = stripTags(inner);
    if (tag === "p" || tag === "blockquote" || tag === "li") { if (text.length < 30) continue; }
    else { if (text.length < 3) continue; }
    if (/^(share|advertisement|sign up|newsletter|read more|related|follow us|copyright|©)/i.test(text)) continue;
    const safe = sanitizeInlineHtml(inner);
    parts.push(tag === "p" ? `<p>${safe}</p>` : `<${tag}>${safe}</${tag}>`);
  }
  const bodyHtml = parts.join("");
  const text = stripTags(bodyHtml);
  const words = text ? text.split(/\s+/).filter(Boolean).length : 0;
  const paras = (bodyHtml.match(/<p>/g) || []).length;
  const topText = stripTags(scope).slice(0, 1500);
  const blocked = BLOCK_RE.test(topText) || BLOCK_RE.test(text.slice(0, 600));

  let status;
  if (blocked && words < 600) status = "BLOCKED";
  else if (words < 60 || paras < 2) status = "MALFORMED";
  else if (words < 130) status = "TOO_SHORT";
  else if (words < FULL_THRESHOLD_WORDS) status = "SUMMARY";
  else status = "FULL";

  return {
    status, canonicalUrl, title, image, author,
    date: date || null,
    bodyHtml: (status === "FULL" || status === "SUMMARY") ? bodyHtml : "",
    words, readMin: Math.max(1, Math.round(words / 220)),
    extractionVersion: "worker-2",
  };
}
