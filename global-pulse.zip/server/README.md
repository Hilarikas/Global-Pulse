# Global Pulse — Extraction Service (Cloudflare Worker)

A tiny server-side service that fetches news pages safely, extracts the full
article, sanitizes it, scores completeness, and returns clean JSON. It also
proxies RSS feeds. Both responses include CORS headers so the app can call it
from anywhere. **No paywall bypass** — blocked pages stay `BLOCKED`.

You can deploy it **entirely in the browser** — no Node, no install.

## Deploy in ~3 minutes (Cloudflare dashboard)

1. Create a free Cloudflare account: https://dash.cloudflare.com/sign-up
2. Left sidebar → **Workers & Pages** → **Create** → **Create Worker**.
3. Give it a name (e.g. `global-pulse-api`) → **Deploy** (it deploys a hello-world).
4. Click **Edit code**. Select all the placeholder code, delete it, and paste the
   **entire contents of `worker.js`** from this folder.
5. Click **Deploy**.
6. Copy your Worker URL — it looks like:
   `https://global-pulse-api.<your-subdomain>.workers.dev`

## Connect it to the app

1. Open Global Pulse → **Settings → Data & sources → Extraction service**.
2. Paste your Worker URL and tap **Save**.
3. Tap **Test** — it should say *Connected*.

From then on the app uses your service for full-article extraction and (in the
browser build) for live feeds — reliably, with no public proxies.

## Endpoints

| Route | Purpose |
|---|---|
| `GET /` | Health/help JSON |
| `GET /feed?url=<rss>` | SSRF-safe RSS/Atom proxy (raw XML) |
| `GET /extract?url=<article>` | Full-article extraction → JSON (`status`, `title`, `image`, `author`, `date`, `bodyHtml`, `words`, `readMin`) |
| `GET /health` | Source success-rates & extraction stats (per-host FULL %, avg latency, status breakdown) |

## Observability (`/health`)

`/health` reports, per source: how many pages were extracted, what percentage
became `FULL`, the status breakdown (FULL/SUMMARY/BLOCKED/…) and average latency —
so you can see which publishers extract cleanly and which don't.

Open it in a browser: `https://<your-worker>.workers.dev/health`

**Persistent stats (optional, ~1 min):** by default stats are *in-memory* and
reset when Cloudflare recycles the isolate. To make them persist:

1. **Workers & Pages → KV → Create a namespace**, name it e.g. `gp-stats`.
2. Open your Worker → **Settings → Variables and Bindings → KV Namespace Bindings
   → Add binding**. Variable name: **`STATS`** → select your `gp-stats` namespace → **Save**.
3. Redeploy (or just save). `/health` will now show `"storage":"kv"` and stats persist.

Without the binding the service still works fully — `/health` just labels the
numbers as ephemeral.

Quick test in your browser:
`https://<your-worker>.workers.dev/extract?url=https://www.bbc.co.uk/news/world`

## Free-tier notes
- Cloudflare Workers free tier allows 100,000 requests/day — ample for one user.
- Responses are cached (~5 min) so repeat opens are instant and easy on publishers.

## Limits / honesty
- Extraction is regex-based (dependency-free so it pastes into the dashboard with
  no build step). It's solid for mainstream article pages; heavily scripted or
  unusual layouts may return `SUMMARY`/`MALFORMED` — the app then shows
  *Open original* rather than a partial article.
- SSRF guard blocks localhost/private/link-local hosts and non-http(s) schemes.
- It never sends cookies/credentials and never bypasses access controls.
