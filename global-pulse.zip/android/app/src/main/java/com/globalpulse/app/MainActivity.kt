package com.globalpulse.app

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Global Pulse — WebView host with a NATIVE feed-fetch bridge.
 *
 * The UI is assets/index.html. Crucially, the RSS feeds are fetched by native
 * Kotlin (HttpURLConnection) — NOT by the WebView's fetch() — so there is no
 * CORS restriction and no dependency on flaky public proxies. The page detects
 * the `GPNative` bridge and uses it, guaranteeing live data whenever the device
 * is online.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        webView = WebView(this)
        webView.layoutParams = FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)
        root.addView(webView)
        setContentView(root)

        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true            // enables localStorage (theme, snapshots, avatar)
            databaseEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            mediaPlaybackRequiresUserGesture = false
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(false)
        }

        // Expose the native fetch bridge to the page (page is our own trusted asset).
        webView.addJavascriptInterface(NativeBridge(), "GPNative")

        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                return if (url.scheme == "http" || url.scheme == "https") {
                    runCatching { startActivity(Intent(Intent.ACTION_VIEW, url)) }
                    true
                } else {
                    false
                }
            }
        }

        webView.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack()
                else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })
    }

    /** JS-callable native networking. Fetches feed URLs directly (no CORS / no proxy). */
    inner class NativeBridge {

        @JavascriptInterface
        fun isNative(): Boolean = true

        /** Fetch every URL in parallel, then hand the raw feed bodies back to JS. */
        @JavascriptInterface
        fun fetchFeeds(urlsJson: String) {
            Thread {
                val urls = try { JSONArray(urlsJson) } catch (e: Exception) { JSONArray() }
                val results = arrayOfNulls<JSONObject>(urls.length())
                val pool = Executors.newFixedThreadPool(6)
                val latch = CountDownLatch(urls.length())
                for (i in 0 until urls.length()) {
                    val idx = i
                    val url = urls.optString(i)
                    pool.execute {
                        val o = JSONObject().put("url", url)
                        try {
                            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                                connectTimeout = 10000
                                readTimeout = 12000
                                instanceFollowRedirects = true
                                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) GlobalPulse/1.0")
                                setRequestProperty("Accept", "application/rss+xml, application/atom+xml, application/xml, text/xml, */*")
                            }
                            val code = conn.responseCode
                            val body = (if (code in 200..299) conn.inputStream else conn.errorStream)
                                ?.bufferedReader()?.use { it.readText() } ?: ""
                            o.put("ok", code in 200..299 && body.isNotEmpty()).put("body", body)
                            conn.disconnect()
                        } catch (e: Exception) {
                            o.put("ok", false).put("body", "")
                        }
                        results[idx] = o
                        latch.countDown()
                    }
                }
                try { latch.await(30, TimeUnit.SECONDS) } catch (e: Exception) {}
                pool.shutdownNow()
                val arr = JSONArray()
                results.forEach { if (it != null) arr.put(it) }
                val payload = JSONObject.quote(arr.toString())
                runOnUiThread {
                    webView.evaluateJavascript("window.__onNativeFeeds && window.__onNativeFeeds($payload)", null)
                }
            }.start()
        }

        /** Fetch a single URL and return its body (used for the podcast directory). */
        @JavascriptInterface
        fun fetchText(url: String, callbackId: String) {
            Thread {
                var body = ""
                try {
                    val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 10000; readTimeout = 12000; instanceFollowRedirects = true
                        setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) GlobalPulse/1.0")
                    }
                    if (conn.responseCode in 200..299) {
                        body = conn.inputStream.bufferedReader().use { it.readText() }
                    }
                    conn.disconnect()
                } catch (e: Exception) {}
                val payload = JSONObject.quote(body)
                runOnUiThread {
                    webView.evaluateJavascript(
                        "window.__onNativeText && window.__onNativeText(${JSONObject.quote(callbackId)}, $payload)", null
                    )
                }
            }.start()
        }
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
