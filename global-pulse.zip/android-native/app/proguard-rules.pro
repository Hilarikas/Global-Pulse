# Default rules are sufficient for this Compose app.
