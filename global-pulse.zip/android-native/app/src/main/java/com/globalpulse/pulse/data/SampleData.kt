package com.globalpulse.pulse.data

/** Offline fallback so the app is never empty (mirrors the web prototype). */
object SampleData {
    fun articles(): List<Article> {
        val now = System.currentTimeMillis()
        fun m(t: String, d: String, src: String, cat: String, mins: Long) =
            Article(t, d, "#", null, src, cat, now - mins * 60_000)
        return listOf(
            m("Global summit opens with new climate finance pledge from major economies",
                "World leaders gathered as several nations announced a joint fund aimed at accelerating clean-energy transition in developing countries.",
                "Reuters", "World", 12),
            m("Leaders agree landmark climate finance package at global summit",
                "A coalition of economies committed billions toward emerging-market energy projects, though details on disbursement remain under negotiation.",
                "BBC", "World", 24),
            m("Climate summit: nations pledge fund but disagreements persist over targets",
                "Negotiators welcomed the finance commitment while cautioning that emissions-reduction timelines are still contested.",
                "Al Jazeera", "World", 31),
            m("Central bank holds rates steady, signals caution on inflation outlook",
                "Policymakers kept the benchmark rate unchanged, citing mixed signals in the labour market and easing but still-elevated prices.",
                "Bloomberg", "Business", 18),
            m("Markets rise as central bank keeps rates on hold",
                "Equities climbed after the decision, with investors weighing guidance for the remainder of the year.",
                "CNBC", "Business", 40),
            m("New AI model shows major leap in scientific reasoning benchmarks",
                "Researchers reported state-of-the-art results on graduate-level problem sets, reigniting debate over evaluation methods.",
                "Ars Technica", "Technology", 9),
            m("AI system posts record scores on reasoning tests, researchers say",
                "The results were released alongside a technical report; independent verification is pending.",
                "The Guardian", "Technology", 22),
            m("Spacecraft returns first close-up images from distant asteroid flyby",
                "Mission scientists released initial imagery revealing an unexpectedly varied surface, with full data downlink continuing.",
                "NASA", "Science", 47),
            m("Probe beams back detailed pictures in historic asteroid encounter",
                "The flyby marks a milestone for the mission, which will spend weeks transmitting collected measurements.",
                "DW", "Science", 58),
            m("Health officials report progress against seasonal outbreak in several regions",
                "Authorities said case numbers were declining but urged continued precautions as monitoring continues.",
                "NPR", "Health", 66),
            m("Regional talks resume amid cautious optimism over ceasefire framework",
                "Mediators described the latest round as constructive, though key sticking points remain unresolved.",
                "France 24", "World", 35),
            m("Diplomatic push gains momentum as parties return to negotiating table",
                "Officials from multiple countries met to advance a proposed framework, with further sessions expected.",
                "Sky News", "World", 52),
            m("Major tech firm unveils next-generation chip aimed at AI workloads",
                "The company said the processor delivers significant efficiency gains; shipping is expected later this year.",
                "CNBC", "Technology", 73),
            m("Record heat prompts warnings across multiple continents",
                "Meteorological agencies issued alerts as temperatures climbed, straining energy grids in several areas.",
                "The Guardian", "Climate", 95)
        )
    }

    fun podcasts(): List<Podcast> = listOf(
        Triple("Global News Daily", "World Media Network", 74),
        Triple("World Politics Today", "Public Radio Intl.", 61),
        Triple("The Intelligence", "Current Affairs Co.", 58),
        Triple("International Briefing", "News Collective", 52),
        Triple("Tech & Science Weekly", "Frontier Media", 47),
        Triple("The Daily Explainer", "Longform Studio", 44),
        Triple("Markets & Money", "Finance Desk", 39),
        Triple("Science Frontiers", "Discovery Audio", 35),
        Triple("The World in 10", "Global Times Audio", 31),
        Triple("Deep Dive Reports", "Investigative Unit", 27)
    ).mapIndexed { i, (name, artist, pct) ->
        Podcast(
            rank = i + 1, name = name, artist = artist, category = "News",
            artUrl = null, feedUrl = null,
            episodeTitle = "Today’s top global story, explained", trendPct = pct
        )
    }
}
