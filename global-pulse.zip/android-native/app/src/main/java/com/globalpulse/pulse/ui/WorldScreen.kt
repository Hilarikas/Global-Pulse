package com.globalpulse.pulse.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.globalpulse.pulse.ui.theme.pulse

private val FLAGS = mapOf(
    "India" to "🇮🇳", "North America" to "🇺🇸", "Europe" to "🇪🇺",
    "Middle East" to "🕌", "Asia-Pacific" to "🌏", "Africa" to "🌍", "South America" to "🌎"
)
private val POS = mapOf(
    "North America" to Offset(0.16f, 0.40f), "South America" to Offset(0.25f, 0.80f),
    "Europe" to Offset(0.50f, 0.32f), "Africa" to Offset(0.53f, 0.63f),
    "Middle East" to Offset(0.60f, 0.50f), "India" to Offset(0.72f, 0.55f),
    "Asia-Pacific" to Offset(0.83f, 0.47f)
)

@Composable
fun WorldScreen(vm: HomeViewModel, state: HomeViewModel.UiState, onOpen: (com.globalpulse.pulse.data.StoryCluster) -> Unit) {
    val p = pulse
    val counts = vm.regionCounts(state)
    val maxCount = (counts.values.maxOrNull() ?: 1).coerceAtLeast(1)
    var selected by remember { mutableStateOf<String?>(null) }
    val top = vm.regionalTop(state, selected)

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(p.bg),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item { ScreenTitle("World Trend Map") }
        item {
            Box(Modifier.padding(horizontal = 20.dp).fillMaxWidth().height(180.dp)
                .clip(RoundedCornerShape(18.dp)).background(p.card2).border(1.dp, p.border, RoundedCornerShape(18.dp))) {
                Canvas(Modifier.fillMaxSize().padding(12.dp)) {
                    counts.forEach { (region, count) ->
                        val pos = POS[region] ?: return@forEach
                        val v = count.toFloat() / maxCount
                        val c = Offset(pos.x * size.width, pos.y * size.height)
                        drawCircle(p.accent.copy(alpha = 0.10f + v * 0.12f), radius = 22f + v * 26f, center = c)
                        drawCircle(p.accent.copy(alpha = 0.35f + v * 0.5f), radius = 8f + v * 16f, center = c)
                    }
                }
            }
        }
        // Region grid, two per row
        val rows = HomeViewModel.REGIONS.chunked(2)
        items(rows.size) { r ->
            Row(Modifier.padding(horizontal = 16.dp, vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                rows[r].forEach { region ->
                    RegionCard(
                        region, FLAGS[region] ?: "🌐", counts[region] ?: 0, maxCount,
                        selected == region, Modifier.weight(1f)
                    ) { selected = if (selected == region) null else region }
                }
                if (rows[r].size == 1) Spacer(Modifier.weight(1f))
            }
        }
        item {
            Text(
                (selected ?: "World") + " Top 10",
                color = p.text, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.padding(20.dp, 18.dp, 20.dp, 8.dp)
            )
        }
        if (top.isEmpty()) {
            item { Text("No signals for this region yet.", color = p.faint, fontSize = 13.sp, modifier = Modifier.padding(20.dp)) }
        } else {
            items(top.size) { i -> Box(Modifier.padding(horizontal = 16.dp)) { NewsRow(top[i], onOpen) } }
        }
    }
}

@Composable
private fun RegionCard(
    name: String, flag: String, count: Int, maxCount: Int,
    active: Boolean, modifier: Modifier, onClick: () -> Unit
) {
    val p = pulse
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).background(p.card)
            .border(1.dp, if (active) p.accent else p.border, RoundedCornerShape(14.dp))
            .clickable { onClick() }.padding(14.dp)
    ) {
        Text("$flag  $name", color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text("$count", color = p.text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            Text("  signals", color = p.faint, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        Box(Modifier.fillMaxWidth().height(4.dp).clip(CircleShape).background(p.border)) {
            Box(Modifier.fillMaxWidth((count.toFloat() / maxCount).coerceIn(0f, 1f)).height(4.dp).clip(CircleShape).background(p.accent))
        }
    }
}
