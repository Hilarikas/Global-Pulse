package com.globalpulse.pulse.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingFlat
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.globalpulse.pulse.data.StoryCluster
import com.globalpulse.pulse.data.TrendState
import com.globalpulse.pulse.data.Verify
import com.globalpulse.pulse.ui.theme.pulse
import kotlin.math.abs

@Composable
fun Pill(text: String, fg: Color, bg: Color, icon: ImageVector? = null) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bg)
            .padding(horizontal = 7.dp, vertical = 3.dp)
    ) {
        if (icon != null) {
            Icon(icon, null, tint = fg, modifier = Modifier.size(12.dp).padding(end = 3.dp))
        }
        Text(text, color = fg, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.3.sp)
    }
}

@Composable
fun StateBadge(state: TrendState) {
    val p = pulse
    val (label, color, icon) = when (state) {
        TrendState.EXPLODING -> Triple("EXPLODING", p.hot, Icons.Filled.LocalFireDepartment)
        TrendState.RISING -> Triple("RISING", p.rising, Icons.Filled.TrendingUp)
        TrendState.STABLE -> Triple("STABLE", p.accent, Icons.Filled.TrendingFlat)
        TrendState.DECLINING -> Triple("DECLINING", p.faint, Icons.Filled.TrendingDown)
    }
    Pill(label, color, color.copy(alpha = 0.14f), icon)
}

@Composable
fun VerifyBadge(cluster: StoryCluster) {
    val p = pulse
    when (cluster.verify) {
        Verify.VERIFIED -> Pill("VERIFIED · ${cluster.sources.size} SOURCES", p.rising, p.rising.copy(alpha = 0.14f), Icons.Filled.CheckCircle)
        Verify.DEVELOPING -> Pill("DEVELOPING", p.hot, p.hot.copy(alpha = 0.14f))
        Verify.SOCIAL -> Pill("SOCIAL REPORTING", p.accent, p.accent.copy(alpha = 0.14f))
    }
}

@Composable
fun CategoryBadge(text: String) {
    val p = pulse
    Pill(text, p.faint, p.card2)
}

/** Simple sparkline chart. */
@Composable
fun Sparkline(data: List<Float>, modifier: Modifier = Modifier, color: Color = pulse.accent) {
    if (data.isEmpty()) return
    Canvas(modifier = modifier) {
        val maxV = data.maxOrNull() ?: 1f; val minV = data.minOrNull() ?: 0f
        val range = (maxV - minV).takeIf { it > 0f } ?: 1f
        val w = size.width; val h = size.height
        val step = if (data.size > 1) w / (data.size - 1) else w
        val path = Path()
        data.forEachIndexed { i, v ->
            val x = i * step
            val y = h - ((v - minV) / range) * (h - 4f) - 2f
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, color = color, style = Stroke(width = 4f, cap = StrokeCap.Round))
    }
}

/** Gradient placeholder derived from the title, so image-less stories still look intentional. */
fun gradientFor(title: String): Brush {
    val hue = (abs(title.hashCode()) % 360).toFloat()
    val c1 = Color.hsv(hue, 0.55f, 0.32f)
    val c2 = Color.hsv((hue + 50f) % 360f, 0.5f, 0.2f)
    return Brush.linearGradient(listOf(c1, c2), start = Offset(0f, 0f), end = Offset(400f, 220f))
}

fun timeAgo(t: Long): String {
    if (t <= 0) return ""
    val s = (System.currentTimeMillis() - t) / 1000
    return when {
        s < 60 -> "just now"
        s < 3600 -> "${s / 60} min ago"
        s < 86400 -> "${s / 3600}h ago"
        else -> "${s / 86400}d ago"
    }
}

fun plural(n: Int, word: String) = "$n $word${if (n == 1) "" else "s"}"

@Composable
fun ScreenTitle(text: String, sub: String? = null) {
    val p = pulse
    Row(
        Modifier.fillMaxWidth().padding(20.dp, 18.dp, 20.dp, 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Bottom
    ) {
        Text(text, color = p.text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        if (sub != null) Text(sub, color = p.faint, fontSize = 12.sp)
    }
}

@Composable
fun FilterPill(text: String, active: Boolean, onClick: () -> Unit) {
    val p = pulse
    Text(
        text,
        color = if (active) p.accent else p.muted,
        fontSize = 12.5.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (active) p.accent.copy(alpha = 0.14f) else p.card)
            .border(1.dp, if (active) p.accent else p.border, RoundedCornerShape(20.dp))
            .clickable { onClick() }
            .padding(horizontal = 13.dp, vertical = 7.dp)
    )
}

@Composable
fun Thumb(cluster: StoryCluster, size: Int) {
    Box(
        Modifier.size(size.dp).clip(RoundedCornerShape(11.dp)).background(gradientFor(cluster.title))
    ) {
        cluster.lead.image?.let {
            AsyncImage(it, null, contentScale = ContentScale.Crop, modifier = Modifier.matchParentSize())
        }
    }
}

@Composable
fun NewsRow(c: StoryCluster, onOpen: (StoryCluster) -> Unit) {
    val p = pulse
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { onOpen(c) }.padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Thumb(c, 64)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(c.title, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, lineHeight = 20.sp, maxLines = 2)
            Text("${c.sources.take(3).joinToString(" · ")} · ${timeAgo(c.latest)}", color = p.faint, fontSize = 11.sp, maxLines = 1)
        }
        val color = when (c.state) {
            TrendState.EXPLODING -> p.hot
            TrendState.DECLINING -> p.faint
            else -> p.rising
        }
        Pill("+${c.pct60}%", color, color.copy(alpha = 0.14f))
    }
}

@Composable
fun PodcastRow(name: String, artist: String, episode: String, artUrl: String?, trendPct: Int) {
    val p = pulse
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).padding(vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)).background(gradientFor(name))) {
            artUrl?.let { AsyncImage(it, null, contentScale = ContentScale.Crop, modifier = Modifier.matchParentSize()) }
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text("🎙 $name", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(episode, color = p.muted, fontSize = 12.sp, maxLines = 1)
            Text("$artist · +$trendPct% trending", color = p.rising, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}
