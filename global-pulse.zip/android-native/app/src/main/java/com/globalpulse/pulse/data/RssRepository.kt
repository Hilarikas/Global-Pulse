package com.globalpulse.pulse.data

import android.util.Xml
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Loads live headlines by fetching each publisher's RSS/Atom feed DIRECTLY
 * (no proxy, no CORS, no rate limit — native networking) and parsing the XML
 * with Android's built-in XmlPullParser. Falls back to bundled sample data only
 * when nothing loads (genuine offline).
 */
class RssRepository {

    /** Loads all feeds in parallel; falls back to sample data if nothing loads. */
    suspend fun load(): NewsLoad = coroutineScope {
        val perFeed = FEEDS.map { feed ->
            async(Dispatchers.IO) {
                feed to runCatching { fetchFeed(feed) }.getOrDefault(emptyList())
            }
        }.awaitAll()
        val statuses = perFeed.map { (f, arts) -> FeedStatus(f.name, arts.isNotEmpty(), arts.size) }
        val seen = HashSet<String>()
        val live = perFeed.flatMap { it.second }.filter { seen.add(it.title.lowercase().take(60)) }
        if (live.isNotEmpty()) NewsLoad(live, false, statuses)
        else NewsLoad(SampleData.articles(), true, statuses)
    }

    private fun fetchFeed(feed: Feed): List<Article> {
        val conn = (URL(feed.url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 10_000
            readTimeout = 12_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) GlobalPulse/1.0")
            setRequestProperty("Accept", "application/rss+xml, application/atom+xml, application/xml, text/xml, */*")
        }
        try {
            if (conn.responseCode !in 200..299) return emptyList()
            val xml = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            return parseFeed(feed, xml)
        } finally {
            conn.disconnect()
        }
    }

    /** Minimal RSS 2.0 / RDF / Atom parser. Namespace-unaware; matches on local names. */
    private fun parseFeed(feed: Feed, xml: String): List<Article> {
        val out = ArrayList<Article>()
        val parser = Xml.newPullParser()
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        parser.setInput(StringReader(xml))

        var inItem = false
        var title = ""; var desc = ""; var link = ""; var img = ""; var date = ""
        val text = StringBuilder()

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    val name = (parser.name ?: "").substringAfter(':').lowercase()
                    if (name == "item" || name == "entry") {
                        inItem = true; title = ""; desc = ""; link = ""; img = ""; date = ""
                    } else if (inItem) {
                        when (name) {
                            "enclosure", "content", "thumbnail" -> {
                                val url = parser.getAttributeValue(null, "url")
                                val type = parser.getAttributeValue(null, "type")
                                if (img.isEmpty() && !url.isNullOrBlank() &&
                                    (type == null || type.startsWith("image") || name == "thumbnail" || name == "enclosure")
                                ) img = url
                            }
                            "link" -> {
                                val href = parser.getAttributeValue(null, "href") // Atom
                                if (!href.isNullOrBlank() && link.isEmpty()) link = href
                            }
                        }
                    }
                    text.setLength(0)
                }
                XmlPullParser.TEXT, XmlPullParser.CDSECT -> text.append(parser.text ?: "")
                XmlPullParser.END_TAG -> {
                    val name = (parser.name ?: "").substringAfter(':').lowercase()
                    val content = text.toString().trim()
                    if (name == "item" || name == "entry") {
                        if (inItem && title.isNotBlank()) {
                            val image = (if (img.isNotBlank()) img else imgFromHtml(desc)).ifBlank { null }
                            out.add(
                                Article(
                                    title = stripHtml(title),
                                    desc = stripHtml(desc).take(320),
                                    link = link,
                                    image = image,
                                    source = feed.name,
                                    category = feed.category,
                                    publishedAt = parseDate(date)
                                )
                            )
                        }
                        inItem = false
                    } else if (inItem) {
                        when (name) {
                            "title" -> if (title.isBlank()) title = content
                            "description", "summary" -> if (desc.isBlank()) desc = content
                            "encoded" -> if (desc.isBlank()) desc = content // content:encoded
                            "content" -> if (desc.isBlank()) desc = content // Atom content
                            "link" -> if (link.isBlank() && content.isNotBlank()) link = content // RSS link text
                            "pubdate", "date", "published", "updated" -> if (date.isBlank()) date = content
                        }
                    }
                    text.setLength(0)
                }
            }
            event = parser.next()
        }
        return out.take(25)
    }

    companion object {
        private val TAG_RE = Regex("<[^>]+>")
        private val WS_RE = Regex("\\s+")
        private val IMG_RE = Regex("<img[^>]+src=\"([^\">]+)\"")
        private val DATE_FORMATS = listOf(
            "EEE, dd MMM yyyy HH:mm:ss Z",
            "EEE, dd MMM yyyy HH:mm:ss zzz",
            "yyyy-MM-dd'T'HH:mm:ssXXX",
            "yyyy-MM-dd'T'HH:mm:ss'Z'",
            "yyyy-MM-dd'T'HH:mm:ssZ",
            "yyyy-MM-dd HH:mm:ss"
        )

        fun stripHtml(s: String?): String =
            s?.replace(TAG_RE, " ")?.replace(WS_RE, " ")?.trim().orEmpty()

        private fun imgFromHtml(s: String?): String =
            s?.let { IMG_RE.find(it)?.groupValues?.get(1) }.orEmpty()

        private fun parseDate(s: String?): Long {
            if (s.isNullOrBlank()) return System.currentTimeMillis()
            val t = s.trim()
            for (f in DATE_FORMATS) {
                try {
                    val fmt = SimpleDateFormat(f, Locale.US); fmt.isLenient = true
                    return fmt.parse(t)?.time ?: continue
                } catch (e: Exception) { /* try next */ }
            }
            return System.currentTimeMillis()
        }
    }
}
