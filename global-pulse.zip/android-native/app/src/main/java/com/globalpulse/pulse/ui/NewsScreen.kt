package com.globalpulse.pulse.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.globalpulse.pulse.data.StoryCluster
import com.globalpulse.pulse.ui.theme.pulse

private val CATEGORIES = listOf("World", "Politics", "Business", "Technology", "Science", "Health", "Sports")

@Composable
fun NewsScreen(vm: HomeViewModel, state: HomeViewModel.UiState, onOpen: (StoryCluster) -> Unit) {
    val p = pulse
    var category by remember { mutableStateOf("World") }
    val list = vm.byCategory(state, category)

    Column(Modifier.fillMaxSize().background(p.bg)) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(CATEGORIES.size) { i ->
                FilterPill(CATEGORIES[i], CATEGORIES[i] == category) { category = CATEGORIES[i] }
            }
        }
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
            Text("$category · ${list.size} stories", color = p.faint, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(bottom = 4.dp))
        }
        if (list.isEmpty()) {
            Text("No stories in this category yet.", color = p.faint, fontSize = 14.sp,
                modifier = Modifier.padding(20.dp))
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp)
            ) {
                items(list.size) { i -> NewsRow(list[i], onOpen) }
            }
        }
    }
}
