package com.globalpulse.pulse.engine

import com.globalpulse.pulse.data.Article
import com.globalpulse.pulse.data.Signals
import com.globalpulse.pulse.data.StoryCluster
import com.globalpulse.pulse.data.TrendState
import com.globalpulse.pulse.data.Verify
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Ports the web prototype's clustering + trend-scoring to Kotlin.
 * Live inputs (sources, recency, coverage) are real; velocity/social/podcast
 * signals are simulated from a deterministic seed and labeled in the UI.
 */
object TrendEngine {

    fun process(articles: List<Article>): List<StoryCluster> =
        cluster(articles).map { score(it) }

    // ---- Clustering (keyword Jaccard + union-find) ----
    private fun cluster(arts: List<Article>): List<List<Article>> {
        if (arts.isEmpty()) return emptyList()
        val kw = arts.map { words(it.title + " " + it.desc.take(80)).toHashSet() }
        val parent = IntArray(arts.size) { it }
        fun find(x0: Int): Int {
            var x = x0
            while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x] }
            return x
        }
        fun unite(a: Int, b: Int) { parent[find(a)] = find(b) }
        for (i in arts.indices) for (j in i + 1 until arts.size) {
            val a = kw[i]; val b = kw[j]
            if (a.size < 2 || b.size < 2) continue
            var inter = 0
            for (w in a) if (w in b) inter++
            if (inter == 0) continue
            val unionSize = a.size + b.size - inter
            val sim = inter.toDouble() / unionSize
            if (sim >= 0.26 || (inter >= 4 && sim >= 0.2)) unite(i, j)
        }
        val groups = LinkedHashMap<Int, MutableList<Article>>()
        arts.forEachIndexed { i, a -> groups.getOrPut(find(i)) { mutableListOf() }.add(a) }
        return groups.values.map { it.sortedByDescending { a -> a.publishedAt } }
    }

    // ---- Scoring ----
    private fun score(group: List<Article>): StoryCluster {
        val now = System.currentTimeMillis()
        val lead = group.firstOrNull { it.image != null } ?: group.first()
        val sources = group.map { it.source }.distinct()
        val srcN = sources.size
        val text = (lead.title + " " + lead.desc).lowercase()
        val allText = group.joinToString(" ") { it.title + " " + it.desc }.lowercase()

        var cat = lead.category; var best = 0
        for ((c, keys) in CAT_KEYS) {
            val n = keys.count { text.contains(it) }
            if (n > best) { best = n; cat = c }
        }
        val regions = REGION_KEYS.filter { (_, keys) -> keys.any { allText.contains(it) } }.keys.toList()

        val latest = group.first().publishedAt
        val recency = max(0.0, 1.0 - (now - latest) / 3.6e6 / 24.0)
        val coverage = min(1.0, srcN / 8.0)
        val geo = min(1.0, regions.size / 4.0)
        val s = seeded(lead.title)
        val social = 0.35 + s * 0.6
        val searchInt = 0.3 + seeded(lead.title + "x") * 0.6
        val podAct = 0.2 + seeded(lead.title + "p") * 0.7
        val heat = s * 0.66 + recency * 0.34
        val velocity = heat

        val trend = (velocity * 30 + coverage * 20 + social * 15 + velocity * 10 +
                geo * 10 + podAct * 5 + searchInt * 5 + coverage * 5).roundToInt().coerceIn(20, 99)
        val importance = (coverage * 34 + geo * 24 + recency * 14 + srcN / 12.0 * 10 +
                (if (cat in IMPORTANT_CATS) 14 else 4)).roundToInt().coerceIn(20, 99)

        val state = when {
            heat > 0.80 -> TrendState.EXPLODING
            heat > 0.55 -> TrendState.RISING
            heat > 0.30 -> TrendState.STABLE
            else -> TrendState.DECLINING
        }
        val verify = when {
            srcN >= 4 -> Verify.VERIFIED
            srcN >= 2 -> Verify.DEVELOPING
            else -> Verify.SOCIAL
        }
        val spark = (0 until 14).map { i ->
            val base = seeded(lead.title + i)
            val tr = if (state == TrendState.DECLINING) (14 - i) / 14f else i / 14f
            (0.15f + base.toFloat() * 0.35f + tr * 0.5f)
        }

        return StoryCluster(
            id = "${lead.title.hashCode()}_${group.size}",
            title = lead.title,
            desc = lead.desc,
            lead = lead,
            articles = group,
            sources = sources,
            category = cat,
            regions = regions,
            latest = latest,
            trend = trend,
            importance = importance,
            state = state,
            verify = verify,
            pct60 = (heat * heat * 430 + 6).roundToInt(),
            pct3h = (heat * 175 + 8).roundToInt(),
            pct24 = (heat * 65 + 5).roundToInt(),
            countries = max(2, (regions.size * 4 + srcN * 1.5 + s * 6).roundToInt()),
            signals = Signals(
                news = (coverage * 100).roundToInt(),
                social = (social * 100).roundToInt(),
                velocity = (velocity * 100).roundToInt(),
                reach = (geo * 100).roundToInt(),
                podcast = (podAct * 100).roundToInt()
            ),
            spark = spark
        )
    }

    // ---- Helpers ----
    private val TOKEN_RE = Regex("[^a-z0-9\\s]")
    private fun words(t: String): List<String> =
        t.lowercase().replace(TOKEN_RE, " ").split(Regex("\\s+"))
            .filter { it.length > 3 && it !in STOP }

    /** FNV-1a → deterministic value in [0,1). */
    private fun seeded(str: String): Double {
        var h = -2128831035 // 2166136261 as signed Int
        for (ch in str) { h = h xor ch.code; h *= 16777619 }
        val u = h.toLong() and 0xFFFFFFFFL
        return (u % 1000) / 1000.0
    }

    private val IMPORTANT_CATS = setOf("World", "Politics", "Science", "Business")

    private val STOP = ("the a an and or but of to in on at for with by from as is are was were be been being " +
            "this that these those it its his her their our your my we they he she you i us them not no new say says " +
            "said after over into out up down about more most other some such than then once here there all any can " +
            "will would could may might amid over against under during while has have had do does did get got make " +
            "made just like new latest update report reports live video watch photos").split(" ").toHashSet()

    private val CAT_KEYS: Map<String, List<String>> = linkedMapOf(
        "Politics" to listOf("election", "president", "minister", "parliament", "senate", "government", "vote", "policy", "congress", "diplomatic", "sanction"),
        "Business" to listOf("market", "stock", "economy", "trade", "company", "earnings", "shares", "inflation", "bank", "fed", "ceo", "revenue", "deal"),
        "Technology" to listOf("ai", "tech", "software", "chip", "apple", "google", "microsoft", "startup", "app", "cyber", "data", "robot", "openai"),
        "Science" to listOf("space", "nasa", "study", "researchers", "scientists", "climate", "physics", "launch", "planet", "satellite", "discovery"),
        "Health" to listOf("health", "virus", "disease", "vaccine", "hospital", "who", "outbreak", "medical", "drug", "cancer"),
        "Sports" to listOf("match", "cup", "league", "win", "championship", "olympic", "final", "player", "coach", "goal", "tournament"),
        "World" to listOf("war", "attack", "military", "border", "protest", "summit", "crisis", "strike", "killed", "forces", "talks")
    )

    private val REGION_KEYS: Map<String, List<String>> = linkedMapOf(
        "India" to listOf("india", "delhi", "modi", "mumbai", "indian", "bengal", "karnataka"),
        "North America" to listOf("us ", "u.s", "america", "washington", "biden", "trump", "canada", "mexico", "york", "california"),
        "Europe" to listOf("europe", "uk", "britain", "london", "france", "germany", "ukraine", "russia", "paris", "berlin", "eu ", "italy", "spain"),
        "Middle East" to listOf("israel", "gaza", "iran", "saudi", "qatar", "syria", "lebanon", "yemen", "emirates", "tehran", "palest"),
        "Asia-Pacific" to listOf("china", "japan", "korea", "beijing", "taiwan", "australia", "pacific", "asia", "tokyo", "philippine", "indonesia"),
        "Africa" to listOf("africa", "nigeria", "kenya", "egypt", "ethiopia", "sudan", "congo", "south africa", "ghana"),
        "South America" to listOf("brazil", "argentina", "chile", "colombia", "venezuela", "peru", "latin")
    )
}
