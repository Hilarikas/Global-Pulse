package com.globalpulse.pulse.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Loads trending news podcasts from the public iTunes Search API.
 * Unlike the browser, a native app has no CORS restriction, so this calls
 * Apple directly. Falls back to bundled samples if the request fails.
 */
class PodcastRepository {

    /** @return podcasts and whether we fell back to sample data. */
    suspend fun load(): Pair<List<Podcast>, Boolean> = withContext(Dispatchers.IO) {
        val live = runCatching { fetchItunes() }.getOrDefault(emptyList())
        if (live.isNotEmpty()) live to false else SampleData.podcasts() to true
    }

    private fun fetchItunes(): List<Podcast> {
        val url = "https://itunes.apple.com/search?term=news&media=podcast&entity=podcast&limit=12"
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"; connectTimeout = 12_000; readTimeout = 12_000
        }
        try {
            if (conn.responseCode !in 200..299) return emptyList()
            val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val results = json.optJSONArray("results") ?: return emptyList()
            val out = ArrayList<Podcast>()
            var rank = 1
            for (i in 0 until results.length()) {
                val it = results.getJSONObject(i)
                val name = it.optString("collectionName")
                if (name.isBlank()) continue
                out.add(
                    Podcast(
                        rank = rank++,
                        name = name,
                        artist = it.optString("artistName"),
                        category = it.optString("primaryGenreName", "News"),
                        artUrl = it.optString("artworkUrl100").replace("100x100", "200x200").ifBlank { null },
                        feedUrl = it.optString("feedUrl").ifBlank { null },
                        episodeTitle = "Latest episode",
                        trendPct = 20 + (name.hashCode() and 0x7fffffff) % 80
                    )
                )
                if (out.size >= 10) break
            }
            return out
        } finally {
            conn.disconnect()
        }
    }
}
