package com.globalpulse.pulse.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Article
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.globalpulse.pulse.data.StoryCluster
import com.globalpulse.pulse.ui.theme.pulse

private data class Tab(val label: String, val icon: ImageVector)

private val TABS = listOf(
    Tab("Home", Icons.Filled.Home),
    Tab("News", Icons.Filled.Article),
    Tab("Podcasts", Icons.Filled.Mic),
    Tab("World", Icons.Filled.Public),
    Tab("Settings", Icons.Filled.Settings)
)

@Composable
fun GlobalPulseApp(
    themeMode: com.globalpulse.pulse.data.ThemeMode,
    onThemeChange: (com.globalpulse.pulse.data.ThemeMode) -> Unit
) {
    val vm: HomeViewModel = viewModel()
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    val p = pulse

    var tab by remember { mutableStateOf(0) }
    var selected by remember { mutableStateOf<StoryCluster?>(null) }

    val openLink: (String) -> Unit = { url ->
        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    }

    if (selected != null) {
        BackHandler { selected = null }
        DetailScreen(selected!!, onBack = { selected = null }, onOpenLink = openLink)
        return
    }

    Scaffold(
        containerColor = p.bg,
        bottomBar = {
            NavigationBar(containerColor = p.card) {
                TABS.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(t.icon, t.label) },
                        label = { Text(t.label, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = p.accent,
                            selectedTextColor = p.accent,
                            unselectedIconColor = p.faint,
                            unselectedTextColor = p.faint,
                            indicatorColor = p.accent.copy(alpha = 0.14f)
                        )
                    )
                }
            }
        }
    ) { inner ->
        Box(Modifier.fillMaxSize().padding(inner)) {
            when (tab) {
                0 -> HomeScreen(
                    state = state,
                    ranked = vm.ranked(state),
                    onRankChange = { vm.setRank(it) },
                    onOpen = { selected = it }
                )
                1 -> NewsScreen(vm, state) { selected = it }
                2 -> PodcastsScreen(state)
                3 -> WorldScreen(vm, state) { selected = it }
                else -> SettingsScreen(state, themeMode, onThemeChange) { vm.refresh() }
            }
        }
    }
}

