package com.globalpulse.pulse.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.globalpulse.pulse.ui.theme.pulse

@Composable
fun PodcastsScreen(state: HomeViewModel.UiState) {
    val p = pulse
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(p.bg),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item { ScreenTitle("Top 10 Podcasts", "News & Politics") }
        if (state.podcastsSample) {
            item {
                Text(
                    "Live podcast directory unavailable — showing sample data",
                    color = p.faint, fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
                )
            }
        }
        items(state.podcasts.size) { i ->
            val pod = state.podcasts[i]
            Box(Modifier.padding(horizontal = 16.dp)) {
                PodcastRow(pod.name, pod.artist, pod.episodeTitle, pod.artUrl, pod.trendPct)
            }
        }
    }
}
