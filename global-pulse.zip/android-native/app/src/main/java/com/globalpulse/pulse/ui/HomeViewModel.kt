package com.globalpulse.pulse.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.globalpulse.pulse.data.FeedStatus
import com.globalpulse.pulse.data.Podcast
import com.globalpulse.pulse.data.Rank
import com.globalpulse.pulse.data.RssRepository
import com.globalpulse.pulse.data.PodcastRepository
import com.globalpulse.pulse.data.StoryCluster
import com.globalpulse.pulse.engine.TrendEngine
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class HomeViewModel : ViewModel() {

    private val repo = RssRepository()
    private val podRepo = PodcastRepository()

    data class UiState(
        val loading: Boolean = true,
        val offline: Boolean = false,
        val clusters: List<StoryCluster> = emptyList(),
        val podcasts: List<Podcast> = emptyList(),
        val podcastsSample: Boolean = false,
        val feedStatuses: List<FeedStatus> = emptyList(),
        val rank: Rank = Rank.TRENDING,
        val lastUpdated: Long = 0L
    )

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    init { refresh() }

    fun refresh() {
        _state.update { it.copy(loading = true) }
        viewModelScope.launch {
            val newsDeferred = async { repo.load() }
            val podDeferred = async { podRepo.load() }
            val news = newsDeferred.await()
            val (pods, podsSample) = podDeferred.await()
            val clusters = TrendEngine.process(news.articles)
            _state.update {
                it.copy(
                    loading = false,
                    offline = news.offline,
                    clusters = clusters,
                    feedStatuses = news.statuses,
                    podcasts = pods,
                    podcastsSample = podsSample,
                    lastUpdated = System.currentTimeMillis()
                )
            }
        }
    }

    fun setRank(rank: Rank) = _state.update { it.copy(rank = rank) }

    /** World Top 10 for the active ranking. */
    fun ranked(state: UiState): List<StoryCluster> =
        state.clusters.sortedByDescending {
            if (state.rank == Rank.TRENDING) it.trend else it.importance
        }.take(10)

    fun byCategory(state: UiState, category: String): List<StoryCluster> =
        state.clusters.filter { it.category == category }.sortedByDescending { it.latest }

    /** Region name -> total signal weight (sum of sources across clusters mentioning it). */
    fun regionCounts(state: UiState): Map<String, Int> {
        val counts = LinkedHashMap<String, Int>()
        REGIONS.forEach { counts[it] = 0 }
        state.clusters.forEach { c ->
            c.regions.forEach { r -> counts[r] = (counts[r] ?: 0) + c.sources.size }
        }
        return counts
    }

    fun regionalTop(state: UiState, region: String?): List<StoryCluster> {
        val base = if (region == null) state.clusters else state.clusters.filter { region in it.regions }
        return base.sortedByDescending { it.trend }.take(10)
    }

    companion object {
        val REGIONS = listOf("India", "North America", "Europe", "Middle East", "Asia-Pacific", "Africa", "South America")
    }
}
