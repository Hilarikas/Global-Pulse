package com.globalpulse.pulse.data

data class Feed(val name: String, val category: String, val url: String)

/** Public RSS feeds — same set as the web prototype. */
val FEEDS = listOf(
    Feed("BBC", "World", "https://feeds.bbci.co.uk/news/world/rss.xml"),
    Feed("The Guardian", "World", "https://www.theguardian.com/world/rss"),
    Feed("Al Jazeera", "World", "https://www.aljazeera.com/xml/rss/all.xml"),
    Feed("DW", "World", "https://rss.dw.com/rdf/rss-en-all"),
    Feed("NPR", "World", "https://feeds.npr.org/1001/rss.xml"),
    Feed("France 24", "World", "https://www.france24.com/en/rss"),
    Feed("Sky News", "World", "https://feeds.skynews.com/feeds/rss/world.xml"),
    Feed("CNBC", "Business", "https://www.cnbc.com/id/100003114/device/rss/rss.html"),
    Feed("Ars Technica", "Technology", "https://feeds.arstechnica.com/arstechnica/index"),
    Feed("NASA", "Science", "https://www.nasa.gov/feed/")
)
