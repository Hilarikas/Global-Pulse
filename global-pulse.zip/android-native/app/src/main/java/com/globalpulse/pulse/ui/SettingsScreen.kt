package com.globalpulse.pulse.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.globalpulse.pulse.data.ThemeMode

@Composable
fun SettingsScreen(
    state: HomeViewModel.UiState,
    themeMode: ThemeMode,
    onThemeChange: (ThemeMode) -> Unit,
    onRefresh: () -> Unit
) {
    val p = pulseColors()
    Column(
        Modifier.fillMaxSize().background(p.bg).verticalScroll(rememberScrollState())
    ) {
        ScreenTitle("Settings")

        Group("Appearance") {
            SettingRow("Theme", "Dark, light or match system") {
                Segmented(
                    options = listOf("System" to ThemeMode.SYSTEM, "Dark" to ThemeMode.DARK, "Light" to ThemeMode.LIGHT),
                    selected = themeMode, onSelect = onThemeChange
                )
            }
        }

        Group("News") {
            SettingRow("Refresh now", "Reload all live feeds") {
                Text("Refresh", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(p.accent)
                        .clickable { onRefresh() }.padding(horizontal = 16.dp, vertical = 8.dp))
            }
        }

        Group("Sources & feed status") {
            if (state.feedStatuses.isEmpty()) {
                Text("Loading…", color = p.faint, fontSize = 13.sp, modifier = Modifier.padding(16.dp))
            } else {
                state.feedStatuses.forEach { f ->
                    Row(
                        Modifier.fillMaxWidth().padding(16.dp, 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(9.dp).clip(CircleShape).background(if (f.ok) p.rising else p.breaking))
                        Spacer(Modifier.size(12.dp))
                        Text(f.name, color = p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text(if (f.ok) "${f.count} items · live" else "unavailable", color = p.faint, fontSize = 11.5.sp)
                    }
                }
            }
        }

        Group("Notifications") {
            ToggleRow("Breaking news", "Only high-confidence events", true)
            ToggleRow("Top 10 changes", "When rankings shift", false)
            ToggleRow("Fast-rising stories", "Rapid attention spikes", true)
            ToggleRow("Daily briefing", "Morning & evening summary", false)
        }

        Text(
            "Global Pulse · Native build v0.1",
            color = pulseColors().faint, fontSize = 12.sp,
            modifier = Modifier.fillMaxWidth().padding(20.dp)
        )
        Spacer(Modifier.size(24.dp))
    }
}

@Composable
private fun pulseColors() = com.globalpulse.pulse.ui.theme.LocalPulseColors.current

@Composable
private fun Group(title: String, content: @Composable () -> Unit) {
    val p = pulseColors()
    Column(
        Modifier.fillMaxWidth().padding(16.dp, 8.dp)
            .clip(RoundedCornerShape(16.dp)).background(p.card).border(1.dp, p.border, RoundedCornerShape(16.dp))
    ) {
        Text(title.uppercase(), color = p.faint, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold,
            letterSpacing = 0.8.sp, modifier = Modifier.padding(16.dp, 14.dp, 16.dp, 6.dp))
        content()
    }
}

@Composable
private fun SettingRow(title: String, subtitle: String, trailing: @Composable () -> Unit) {
    val p = pulseColors()
    Row(
        Modifier.fillMaxWidth().padding(16.dp, 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = p.text, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = p.faint, fontSize = 12.sp)
        }
        trailing()
    }
}

@Composable
private fun <T> Segmented(options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit) {
    val p = pulseColors()
    Row(
        Modifier.clip(RoundedCornerShape(10.dp)).background(p.card2).border(1.dp, p.border, RoundedCornerShape(10.dp)).padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        options.forEach { (label, value) ->
            val active = value == selected
            Text(
                label, color = if (active) p.text else p.faint, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(RoundedCornerShape(8.dp))
                    .background(if (active) p.card else Color.Transparent)
                    .clickable { onSelect(value) }.padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }
    }
}

@Composable
private fun ToggleRow(title: String, subtitle: String, default: Boolean) {
    val p = pulseColors()
    var on by remember { mutableStateOf(default) }
    Row(
        Modifier.fillMaxWidth().padding(16.dp, 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = p.text, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = p.faint, fontSize = 12.sp)
        }
        Switch(
            checked = on, onCheckedChange = { on = it },
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = p.accent,
                uncheckedTrackColor = p.border
            )
        )
    }
}
