package com.globalpulse.pulse.data

/** A single normalized news item from one publisher feed. */
data class Article(
    val title: String,
    val desc: String,
    val link: String,
    val image: String?,
    val source: String,
    val category: String,
    val publishedAt: Long
)

enum class TrendState { EXPLODING, RISING, STABLE, DECLINING }

enum class Verify { VERIFIED, DEVELOPING, SOCIAL }

/** Simulated attention signals (0..100), labeled as such in the UI. */
data class Signals(
    val news: Int,
    val social: Int,
    val velocity: Int,
    val reach: Int,
    val podcast: Int
)

/** One deduplicated event, clustered from many articles across sources. */
data class StoryCluster(
    val id: String,
    val title: String,
    val desc: String,
    val lead: Article,
    val articles: List<Article>,
    val sources: List<String>,
    val category: String,
    val regions: List<String>,
    val latest: Long,
    val trend: Int,
    val importance: Int,
    val state: TrendState,
    val verify: Verify,
    val pct60: Int,
    val pct3h: Int,
    val pct24: Int,
    val countries: Int,
    val signals: Signals,
    val spark: List<Float>
)

enum class Rank { TRENDING, IMPORTANT }

enum class ThemeMode { SYSTEM, DARK, LIGHT }

data class Podcast(
    val rank: Int,
    val name: String,
    val artist: String,
    val category: String,
    val artUrl: String?,
    val feedUrl: String?,
    val episodeTitle: String,
    val trendPct: Int
)

data class FeedStatus(val name: String, val ok: Boolean, val count: Int)

/** Result of a feed load: articles, whether we fell back to sample data, per-feed status. */
data class NewsLoad(val articles: List<Article>, val offline: Boolean, val statuses: List<FeedStatus>)
