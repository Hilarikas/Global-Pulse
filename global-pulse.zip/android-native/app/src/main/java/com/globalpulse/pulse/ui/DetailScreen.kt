package com.globalpulse.pulse.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.globalpulse.pulse.data.StoryCluster
import com.globalpulse.pulse.ui.theme.pulse
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DetailScreen(c: StoryCluster, onBack: () -> Unit, onOpenLink: (String) -> Unit) {
    val p = pulse
    Column(Modifier.fillMaxSize().background(p.bg).verticalScroll(rememberScrollState())) {
        Box(Modifier.fillMaxWidth().height(220.dp).background(gradientFor(c.title))) {
            c.lead.image?.let {
                AsyncImage(it, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            }
            Box(
                Modifier.padding(14.dp).size(38.dp).clip(RoundedCornerShape(11.dp))
                    .background(p.card).clickable { onBack() }, Alignment.Center
            ) { Icon(Icons.Filled.ArrowBack, "Back", tint = p.text, modifier = Modifier.size(20.dp)) }
        }
        Column(Modifier.padding(22.dp, 18.dp, 22.dp, 40.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                StateBadge(c.state); VerifyBadge(c); CategoryBadge(c.category)
            }
            Spacer(Modifier.height(12.dp))
            Text(c.title, color = p.text, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 29.sp)
            Spacer(Modifier.height(10.dp))
            Text("${plural(c.sources.size, "source")} · +${c.pct60}% (60m) · ${c.countries} countries · ${timeAgo(c.latest)}",
                color = p.faint, fontSize = 12.sp)

            Header("AI SUMMARY")
            Text("${c.desc} Coverage consolidated from ${plural(c.sources.size, "source")}: ${c.sources.take(5).joinToString(", ")}.",
                color = p.muted, fontSize = 15.sp, lineHeight = 24.sp)
            Text("AI-generated summary · grounded in ${c.articles.size} retrieved reports", color = p.faint, fontSize = 11.sp,
                modifier = Modifier.padding(top = 8.dp))

            Header("WHY IS THIS TRENDING?")
            SignalBar("News coverage", c.signals.news)
            SignalBar("Social activity", c.signals.social)
            SignalBar("Growth velocity", c.signals.velocity)
            SignalBar("Global reach", c.signals.reach)
            SignalBar("Podcast activity", c.signals.podcast)
            Text("Activity increased +${c.pct60}% in the last 60 min · +${c.pct3h}% (3h) · +${c.pct24}% (24h) — velocity simulated in prototype",
                color = p.faint, fontSize = 11.sp, modifier = Modifier.padding(top = 12.dp))

            Header("HOW DIFFERENT SOURCES ARE REPORTING THIS")
            c.articles.take(5).forEach { a ->
                Column(
                    Modifier.fillMaxWidth().padding(bottom = 9.dp).clip(RoundedCornerShape(12.dp))
                        .background(p.card).border(1.dp, p.border, RoundedCornerShape(12.dp)).padding(13.dp)
                ) {
                    Text(a.source, color = p.accent, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(3.dp))
                    Text(a.title, color = p.text, fontSize = 14.sp, lineHeight = 20.sp)
                }
            }

            Header("STORY TIMELINE")
            val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
            c.articles.sortedBy { it.publishedAt }.take(5).forEach { a ->
                Row(Modifier.padding(bottom = 12.dp)) {
                    Text(fmt.format(Date(a.publishedAt)), color = p.accent, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.width(56.dp))
                    Text("${a.source} — ${a.title}", color = p.muted, fontSize = 13.sp, lineHeight = 18.sp)
                }
            }

            if (c.lead.link.isNotBlank() && c.lead.link != "#") {
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.clip(RoundedCornerShape(11.dp)).background(p.accent)
                        .clickable { onOpenLink(c.lead.link) }.padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Read original at ${c.lead.source}", color = androidx.compose.ui.graphics.Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.Filled.OpenInNew, null, tint = androidx.compose.ui.graphics.Color.White, modifier = Modifier.size(15.dp))
                }
            }
        }
    }
}

@Composable
private fun Header(text: String) {
    Text(text, color = pulse.accent, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp,
        modifier = Modifier.padding(top = 22.dp, bottom = 9.dp))
}

@Composable
private fun SignalBar(label: String, value: Int) {
    val p = pulse
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = p.muted, fontSize = 12.sp, modifier = Modifier.width(120.dp))
        Box(Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(6.dp)).background(p.border)) {
            Box(Modifier.fillMaxWidth(value / 100f).height(8.dp).clip(RoundedCornerShape(6.dp)).background(p.accent))
        }
        Text("$value%", color = p.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(42.dp), textAlign = androidx.compose.ui.text.style.TextAlign.End)
    }
}
