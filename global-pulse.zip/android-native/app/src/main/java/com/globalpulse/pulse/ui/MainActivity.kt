package com.globalpulse.pulse.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.globalpulse.pulse.data.ThemeMode
import com.globalpulse.pulse.data.ThemePrefs
import com.globalpulse.pulse.ui.theme.PulseTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val context = LocalContext.current
            var mode by remember { mutableStateOf(ThemePrefs.load(context)) }
            val dark = when (mode) {
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
                ThemeMode.DARK -> true
                ThemeMode.LIGHT -> false
            }
            PulseTheme(darkTheme = dark) {
                GlobalPulseApp(
                    themeMode = mode,
                    onThemeChange = { mode = it; ThemePrefs.save(context, it) }
                )
            }
        }
    }
}
