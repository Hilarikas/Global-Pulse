package com.globalpulse.pulse.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.globalpulse.pulse.data.Rank
import com.globalpulse.pulse.data.StoryCluster
import com.globalpulse.pulse.ui.theme.pulse
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    state: HomeViewModel.UiState,
    ranked: List<StoryCluster>,
    onRankChange: (Rank) -> Unit,
    onOpen: (StoryCluster) -> Unit
) {
    val p = pulse
    LazyColumn(
        modifier = Modifier.fillMaxWidth().background(p.bg),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp)
    ) {
        item { Header(state) }
        item { RankToggle(state.rank, onRankChange) }
        item {
            SectionTitle("World Top 10", if (state.rank == Rank.TRENDING) "Trending now" else "Most important")
        }
        if (ranked.isEmpty()) {
            item { EmptyState() }
        } else {
            item { HeroCard(ranked.first(), state.rank, onOpen) }
            val meds = ranked.drop(1).take(4)
            items(meds.chunked(2).size) { rowIdx ->
                val row = meds.chunked(2)[rowIdx]
                Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEachIndexed { i, c ->
                        Box(Modifier.weight(1f)) { MediumCard(c, rowIdx * 2 + i + 2, onOpen) }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            item { CompactList(ranked.drop(5).take(5), 6, state.rank, onOpen) }
            item { SectionTitle("Fastest Rising", "Last 60 min") }
            item { RisingRow(state.clusters.sortedByDescending { it.pct60 }.take(8), onOpen) }
        }
    }
}

@Composable
private fun Header(state: HomeViewModel.UiState) {
    val p = pulse
    val now = remember(state.lastUpdated) { Date() }
    val dateStr = remember(state.lastUpdated) {
        SimpleDateFormat("EEEE, d MMMM yyyy · HH:mm", Locale.getDefault()).format(now)
    }
    Column(Modifier.fillMaxWidth().padding(20.dp, 16.dp, 20.dp, 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(p.accent), Alignment.Center) {
                Text("◉", color = androidx.compose.ui.graphics.Color.White, fontSize = 18.sp)
            }
            Spacer(Modifier.width(11.dp))
            Column {
                Text("Global Pulse", color = p.text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(7.dp).clip(RoundedCornerShape(50)).background(p.breaking))
                    Spacer(Modifier.width(5.dp))
                    Text("LIVE", color = p.breaking, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.6.sp)
                    Spacer(Modifier.width(8.dp))
                    Text(dateStr, color = p.faint, fontSize = 12.sp)
                }
            }
        }
        Spacer(Modifier.height(9.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (state.offline) {
                Pill("OFFLINE · SAMPLE DATA", p.breaking, p.breaking.copy(alpha = 0.14f))
                Spacer(Modifier.width(8.dp))
            }
            val updated = if (state.loading) "updating…" else timeAgo(state.lastUpdated)
            Text("Last updated $updated", color = p.faint, fontSize = 12.sp)
        }
    }
}

@Composable
private fun RankToggle(rank: Rank, onChange: (Rank) -> Unit) {
    val p = pulse
    Row(
        Modifier.fillMaxWidth().padding(16.dp, 6.dp)
            .clip(RoundedCornerShape(13.dp)).background(p.card2)
            .border(1.dp, p.border, RoundedCornerShape(13.dp)).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        SegButton("TRENDING", "Gaining attention fastest", rank == Rank.TRENDING, Modifier.weight(1f)) { onChange(Rank.TRENDING) }
        SegButton("IMPORTANT", "Greatest global significance", rank == Rank.IMPORTANT, Modifier.weight(1f)) { onChange(Rank.IMPORTANT) }
    }
}

@Composable
private fun SegButton(title: String, sub: String, active: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val p = pulse
    Column(
        modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (active) p.card else androidx.compose.ui.graphics.Color.Transparent)
            .clickable { onClick() }
            .padding(vertical = 9.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, color = if (active) p.text else p.faint, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Text(sub, color = if (active) p.accent else p.faint, fontSize = 10.sp)
    }
}

@Composable
private fun SectionTitle(title: String, link: String) {
    val p = pulse
    Row(
        Modifier.fillMaxWidth().padding(20.dp, 20.dp, 20.dp, 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Bottom
    ) {
        Text(title, color = p.text, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
        Text(link, color = p.faint, fontSize = 12.sp)
    }
}

@Composable
private fun CardImage(cluster: StoryCluster, height: Int) {
    Box(Modifier.fillMaxWidth().height(height.dp).background(gradientFor(cluster.title))) {
        cluster.lead.image?.let { url ->
            AsyncImage(model = url, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().height(height.dp))
        }
    }
}

@Composable
private fun HeroCard(c: StoryCluster, rank: Rank, onOpen: (StoryCluster) -> Unit) {
    val p = pulse
    Column(
        Modifier.padding(16.dp, 6.dp).clip(RoundedCornerShape(18.dp))
            .background(p.card).border(1.dp, p.border, RoundedCornerShape(18.dp))
            .clickable { onOpen(c) }
    ) {
        CardImage(c, 200)
        Column(Modifier.padding(18.dp, 16.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("01", color = p.faint, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                StateBadge(c.state); VerifyBadge(c); CategoryBadge(c.category)
            }
            Spacer(Modifier.height(10.dp))
            Text(c.title, color = p.text, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 28.sp)
            Spacer(Modifier.height(10.dp))
            Text(c.desc, color = p.muted, fontSize = 15.sp, lineHeight = 23.sp, maxLines = 4)
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("${plural(c.sources.size, "source")}  ·  +${c.pct60}%  ·  ${c.countries} countries",
                    color = p.faint, fontSize = 12.sp)
                Sparkline(c.spark, Modifier.size(90.dp, 30.dp))
            }
        }
    }
}

@Composable
private fun MediumCard(c: StoryCluster, rank: Int, onOpen: (StoryCluster) -> Unit) {
    val p = pulse
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
            .background(p.card).border(1.dp, p.border, RoundedCornerShape(18.dp))
            .clickable { onOpen(c) }
    ) {
        CardImage(c, 110)
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(String.format("%02d", rank), color = p.faint, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                StateBadge(c.state)
            }
            Spacer(Modifier.height(8.dp))
            Text(c.title, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Bold, lineHeight = 21.sp, maxLines = 3)
            Spacer(Modifier.height(8.dp))
            Text("${plural(c.sources.size, "source")} · +${c.pct60}% · ${timeAgo(c.latest)}", color = p.faint, fontSize = 11.sp)
        }
    }
}

@Composable
private fun CompactList(items: List<StoryCluster>, startRank: Int, rank: Rank, onOpen: (StoryCluster) -> Unit) {
    val p = pulse
    Column(Modifier.padding(16.dp, 8.dp)) {
        items.forEachIndexed { i, c ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { onOpen(c) }.padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(String.format("%02d", startRank + i), color = p.faint, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.width(28.dp))
                Column(Modifier.weight(1f).padding(end = 10.dp)) {
                    Text(c.title, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, lineHeight = 21.sp, maxLines = 2)
                    Text("${c.sources.take(3).joinToString(" · ")} · +${c.pct60}%", color = p.faint, fontSize = 11.sp, maxLines = 1)
                }
                Sparkline(c.spark, Modifier.size(56.dp, 22.dp))
            }
        }
    }
}

@Composable
private fun RisingRow(items: List<StoryCluster>, onOpen: (StoryCluster) -> Unit) {
    val p = pulse
    LazyRow(
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(items.size) { i ->
            val c = items[i]
            Column(
                Modifier.width(180.dp).clip(RoundedCornerShape(16.dp)).background(p.card)
                    .border(1.dp, p.border, RoundedCornerShape(16.dp)).clickable { onOpen(c) }.padding(15.dp)
            ) {
                Text(String.format("%02d", i + 1), color = p.faint, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                Text("+${c.pct60}%", color = p.rising, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                Text("Last 60 min", color = p.faint, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text(c.title, color = p.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, lineHeight = 18.sp, maxLines = 3)
            }
        }
    }
}

@Composable
private fun EmptyState() {
    val p = pulse
    Column(Modifier.fillMaxWidth().padding(40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("No significant trend detected", color = p.muted, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("Not enough independent signals are currently available.", color = p.faint, fontSize = 13.sp)
    }
}
