package com.globalpulse.pulse.data

import android.content.Context

/** Persists the user's theme choice so it survives restarts (spec: no crash/reset on change). */
object ThemePrefs {
    private const val FILE = "global_pulse_prefs"
    private const val KEY = "theme_mode"

    fun load(context: Context): ThemeMode {
        val name = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getString(KEY, ThemeMode.SYSTEM.name) ?: ThemeMode.SYSTEM.name
        return runCatching { ThemeMode.valueOf(name) }.getOrDefault(ThemeMode.SYSTEM)
    }

    fun save(context: Context, mode: ThemeMode) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putString(KEY, mode.name).apply()
    }
}
