package com.globalpulse.pulse.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** Extended palette beyond Material's slots (trend states, borders, muted text). */
data class PulseColors(
    val bg: Color,
    val card: Color,
    val card2: Color,
    val border: Color,
    val text: Color,
    val muted: Color,
    val faint: Color,
    val accent: Color,
    val breaking: Color,
    val rising: Color,
    val hot: Color,
    val isDark: Boolean
)

private val DarkPulse = PulseColors(
    bg = Color(0xFF0A0E17), card = Color(0xFF121A28), card2 = Color(0xFF0E1622),
    border = Color(0xFF1E2A3D), text = Color(0xFFEAF0F7), muted = Color(0xFF9FB0C4),
    faint = Color(0xFF647388), accent = Color(0xFF38BDF8), breaking = Color(0xFFFF5A52),
    rising = Color(0xFF34D399), hot = Color(0xFFFBA94C), isDark = true
)

private val LightPulse = PulseColors(
    bg = Color(0xFFF4F5F7), card = Color(0xFFFFFFFF), card2 = Color(0xFFFAFBFC),
    border = Color(0xFFE4E7EC), text = Color(0xFF14171F), muted = Color(0xFF4B5563),
    faint = Color(0xFF8A93A2), accent = Color(0xFF0B7FE0), breaking = Color(0xFFE5342B),
    rising = Color(0xFF17A673), hot = Color(0xFFF0891B), isDark = false
)

val LocalPulseColors = staticCompositionLocalOf { DarkPulse }

/** Convenience accessor: `pulse.accent`, `pulse.card`, … */
val pulse: PulseColors
    @Composable get() = LocalPulseColors.current

@Composable
fun PulseTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val p = if (darkTheme) DarkPulse else LightPulse
    val scheme = if (darkTheme) {
        darkColorScheme(
            primary = p.accent, background = p.bg, surface = p.card,
            onPrimary = Color.White, onBackground = p.text, onSurface = p.text,
            surfaceVariant = p.card2, outline = p.border, error = p.breaking
        )
    } else {
        lightColorScheme(
            primary = p.accent, background = p.bg, surface = p.card,
            onPrimary = Color.White, onBackground = p.text, onSurface = p.text,
            surfaceVariant = p.card2, outline = p.border, error = p.breaking
        )
    }
    androidx.compose.runtime.CompositionLocalProvider(LocalPulseColors provides p) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
